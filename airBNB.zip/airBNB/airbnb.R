#1. Initial Data Loading and Display
library(readr)
library(dplyr)
library(stringr)

polluted_data <- read_csv('AirbnbSet2Polluted.csv')

head(polluted_data)



#2. Categorical Data Initial Analysis
# Checking unique values 
categorical_columns <- c('neighbourhood group', 'neighbourhood', 'room and type', 'floor')
for (column in categorical_columns) {
  print(paste("Unique values in", column, ":"))
  print(unique(polluted_data[[column]]))
}





#3. Numerical Data Initial Analysis and Conversion
# Check and convert numerical columns 
numerical_columns <- c('minimum nights', 'number_of_reviews', 'reviews_per_month', 'noise(dB)', 'Price($)')
polluted_data <- polluted_data %>%
  mutate(across(all_of(numerical_columns), as.numeric))

# Displaying summary 
summary(select(polluted_data, all_of(numerical_columns)))






#4. Standardizing Categorical Data
# trimming, lowercasing, and removing special characters
clean_string <- function(s) {
  s <- str_trim(s)
  s <- tolower(s)
  s <- str_replace_all(s, "[^a-z0-9\\s]", "")
  return(s)
}

# Function for standardizing 
partial_match_neighbourhood_group <- function(name) {
  name <- clean_string(name)
  if (str_detect(name, 'brooklyn')) return('Brooklyn')
  else if (str_detect(name, 'manhattan')) return('Manhattan')
  else if (str_detect(name, 'queens')) return('Queens')
  else if (str_detect(name, 'bronx')) return('Bronx')
  else if (str_detect(name, 'staten')) return('Staten Island')
  else return(toupper(substr(name, 1, 1)) %>% paste0(substr(name, 2, nchar(name))))
}

# Apply the cleaning and partial matching to 'neighbourhood group' and 'neighbourhood'
polluted_data <- polluted_data %>%
  mutate(`neighbourhood group` = map_chr(`neighbourhood group`, partial_match_neighbourhood_group),
         neighbourhood = map_chr(neighbourhood, clean_string))

# Apply similar cleaning to 'room and type'
polluted_data <- polluted_data %>%
  mutate(`room and type` = map_chr(`room and type`, clean_string))

# Checking the unique values 
unique(polluted_data$`neighbourhood group`)
unique(polluted_data$neighbourhood)
unique(polluted_data$`room and type`)




#Step 5: Finalizing Categorical Data and Cleaning Floor Data
# Finalizing the cleaning of 'room and type' column
standardize_room_type <- function(name) {
  name <- tolower(name)
  name <- gsub("[^a-z0-9\\s]", "", name)
  name <- gsub(" +", " ", str_trim(name)) # Remove extra spaces and trim
  
  if (grepl("private", name)) {
    return('Private room')
  } else if (grepl("entire", name)) {
    return('Entire home/apt')
  } else if (grepl("shared", name)) {
    return('Shared room')
  } else {
    return(NA) # NA for unclear room types
  }
}

polluted_data$`room and type` <- sapply(polluted_data$`room and type`, standardize_room_type)

# Cleaning 'floor' data
clean_floor_data <- function(floor) {
  if (is.na(floor) || !is.character(floor)) {
    return(NA)
  }
  
  # Mapping textual to numeric
  text_to_num <- list(
    one = 1, two = 2, three = 3, four = 4, five = 5, six = 6, seven = 7, 
    eight = 8, nine = 9, ten = 10, eleven = 11, twelve = 12, thirteen = 13,
    fourteen = 14, fifteen = 15, sixteen = 16, seventeen = 17, eighteen = 18,
    nineteen = 19, twenty = 20, "twenty one" = 21, "twenty two" = 22, "twenty three" = 23,
    "twenty four" = 24, "twenty five" = 25, "twenty six" = 26, "twenty seven" = 27,
    "twenty eight" = 28, "twenty nine" = 29, thirty = 30
  )
  
  floor_clean <- tolower(gsub("[^a-z0-9 ]", "", floor))
  floor_clean <- gsub(" +", " ", str_trim(floor_clean)) # Remove extra spaces and trim
  
  if (floor_clean %in% names(text_to_num)) {
    return(text_to_num[[floor_clean]])
  } else if (grepl("^[0-9]+$", floor_clean)) {
    return(as.numeric(floor_clean))
  } else {
    return(NA)
  }
}

polluted_data$floor <- sapply(polluted_data$floor, clean_floor_data)







#Step 6: Addressing Numerical Data Outliers
# Function to handle outliers
replace_outliers_with_median <- function(column) {
  median_value <- median(polluted_data[[column]], na.rm = TRUE)
  std_dev <- sd(polluted_data[[column]], na.rm = TRUE)
  upper_limit <- median_value + 3 * std_dev
  lower_limit <- median_value - 3 * std_dev
  polluted_data[[column]] <- ifelse(polluted_data[[column]] > upper_limit | polluted_data[[column]] < lower_limit, median_value, polluted_data[[column]])
}

# Apply outlier handling to numerical columns
numerical_columns_outliers <- c('minimum nights', 'number_of_reviews', 'reviews_per_month', 'noise(dB)', 'Price($)')
for (column in numerical_columns_outliers) {
  replace_outliers_with_median(column)
}



#Step 7: Saving Cleaned Data and Preparing Pollution Summary
# Saving the cleaned dataset
write_csv(polluted_data, 'Cleaned_AirbnbSet2.csv')

# Preparing the pollution summary CSV
pollution_summary <- data.frame(
  `Row #` = c('Various', 'Various', 'Various', 'Various', 'Various'),
  `Column Name` = c('neighbourhood group', 'neighbourhood', 'room and type', 'floor', 'numerical columns'),
  `Justification (optional)` = c(
    'Standardized inconsistent naming (e.g., Brooklyn variations)',
    'Cleaned and standardized neighborhood names',
    'Corrected room type naming inconsistencies',
    'Converted textual representations to numeric, handled invalid entries',
    'Handled outliers in minimum nights, number of reviews, reviews per month, noise, and price'
  )
)

# Saving the pollution summary 
write_csv(pollution_summary, 'Pollution_Summary.csv')







